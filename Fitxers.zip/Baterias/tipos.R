# Programa per a incorporar mecanicament una columna a pregs que les clasifique
# de la forma següent (factor): 1 = teorica, 2=numerica, 3=teorica-practica.

pregs$type <- NA

for (i in 1:nrow(pregs)) {

    print(paste(pregs$clause[i], pregs$opa[i],pregs$opb[i]))
    x <- readline("1 = teorica, 2=numerica, 3=teorica-practica: ")
    pregs$type[i] <- as.numeric(x)
    print
    }

# multinomial.test(predicted,observed vector) per a un test de proporcions
# multinomial on predicted serán les proporcions de cada type en el conjunt
# de la base de dades y observed el recompte (num.casos) dels tres types en
# la submostra de pregs$fail == TRUE.
