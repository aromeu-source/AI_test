# Aquest codi val per a convertir fitxers en ASCII TXT amb les preguntes de...
# les bateries a un format que R puga llegir de valors separats per la barra..
# vertical. No podem utilitzar comma separated values perquè hi ha variables..
# que són cadenes.............................................................
# (c) A.Romeu 2023............................................................
library(stringr)
pregs <- read.csv(file="Intro2.Bateria.txt",header=TRUE,sep="|")

pregs$true_a <- str_detect(pregs$opa,regex("\\(a\\)[*]"))
pregs$true_b <- str_detect(pregs$opb,regex("\\(b\\)[*]"))
pregs$tema <- c(    rep(1,62) , 
                    rep(2,68) , 
                    rep(3,86), 
                    rep(4,71), 
                    rep(5,75), 
                    rep(6,74), 
                    rep(7,76), 
                    rep(8,54) )
pregs$numero <- c(1:62, 1:68, 1:86, 1:71, 1:75, 1:74, 1:76, 1:54)
                    
