# =============================================================================
# EXPERIMENT.R: Aquest programa per a obtindre els resultats dels experiments.
# -----------------------------------------------------------------------------
# DISSENY DELS EXPERIMENTS:
#
#   Dos tractaments:
#                       - Tractament A(B): Indiquem (no) bibliografia prèvia.
#                         La bibiografia prèvia s'indica amb la pregunta:
#
#  "A continuación voy a hacerte una serie de preguntas de macroeconomía y
#  "deberás responder basándote fundamentalmente en el manual Economia de los 
#  "autores Mankiw y Taylor del año 2017. Lo has entendido?".
#
#   Per a cada tractament, utilitzarem una clau diferent i farem una primera
#   ronda, (ronda 1), de 100 preguntes, seguides de 1 ronda d'entrenament de
#   500 preguntes i finalment, una segonda ronda (ronda 2). 
#   Només guardem els resultats de les rondes "ronda 1" y "ronda 2".
# -----------------------------------------------------------------------------
load("Intro2.Bateria.Rdat")
source("CHATpros.R")
# Claus per als diferents tractaments..........................................
keyA <- "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"
keyB <- "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"
# Nom de la sessió i clau: MODIFICAR ACÍ......................................
nomses <- "B2"
key <- keyB
# Text Introductori (igual per a totes les sessions)...........................
hello <- "Responde simplemente (a) o (b) sin dar explicaciones detalladas: "
# Número de preguntes per ronda................................................
npregs <- 100
# Crea data.frame inicial sobre el qual acumul·lar.............................
ExpDat <- data.frame(tema=NA,numero=NA,secuencial=NA,
                   true_reply=NA,GPT_reply=NA,encert=NA,temps=NA)
# Comença bucle................................................................
for ( i in 1:npregs ) {
    resultat <-  make_question(pregs,  
                               indice=c(NA,NA,sample(1:nrow(pregs),1)), 
                               APIkey=key, 
                               pretext=hello)
    if (length(resultat$GPT_reply)==0) {
        resultat$GPT_reply <- NA
        resultat$encert <- NA
    }
    ExpDat <- rbind(ExpDat,resultat)
}
ExpDat <- ExpDat[-1,] 
ExpDat <- cbind(numord=seq(1,npregs),sesnom=rep(nomses,npregs),ExpDat)
